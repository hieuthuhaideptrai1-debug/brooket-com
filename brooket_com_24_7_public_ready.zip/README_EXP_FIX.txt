EXP SYSTEM FIX
- The second top-bar stat is now EXP (not ESP).
- Opening any pack gives +10 base EXP.
- Rarity bonus: Mythical +100, Chroma +50, Epic +20, Rare +10, Uncommon +5, Common +2.
- Leaderboard is ranked by EXP, highest first.
- Tokens remain the currency used to buy packs and are not used as the leaderboard score.
- Existing account data is preserved; XP is initialized to 0 only when an account has no XP field.
