SHARED LEADERBOARD FINAL

1. Double-click START_SERVER.bat.
2. Keep the black server window open.
3. Use http://localhost:3000/ instead of opening index.html with file://.
4. The Admin account Blooketstudio and all clone accounts are stored in the same root users-data.json and read by /api/leaderboard.
5. If you already had old browser data, refresh after starting the server.
