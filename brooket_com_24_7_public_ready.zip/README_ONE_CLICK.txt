ONE-CLICK WEB START
===================

1. Extract this ZIP to any folder.
2. Double-click START_WEB.bat.
3. The first run may download a portable Node.js runtime and install the WebSocket package.
4. Your browser will open http://localhost:3000/ automatically.
5. Keep the black server window open while using the site.

You do NOT need to install Node.js manually.

If Windows SmartScreen appears, choose More info -> Run anyway only if you trust the file you downloaded.
