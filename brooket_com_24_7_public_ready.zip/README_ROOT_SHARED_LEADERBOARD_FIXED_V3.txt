ROOT SHARED LEADERBOARD FIX V3

This version makes every account use the same Node root account database and the same /api/leaderboard endpoint.

IMPORTANT:
1. Run START_SERVER.bat from THIS folder.
2. Keep the server window open.
3. Use http://localhost:3000/ (the batch file opens it automatically).
4. Do not open separate copies with separate START_SERVER.bat windows. All players/clones must connect to the same root server on port 3000.

Fixes:
- Local browser accounts are merged into the shared root instead of replacing the root database.
- Remote accounts win when they are newer.
- New/local accounts are pushed to the root server.
- Admin Blooketstudio is stored in the exact same shared account map.
- Leaderboard reads the canonical shared server and flushes local changes before reading it.
- Server can still start if ws is not installed; chat/realtime presence is simply disabled until npm install is run.
- Existing users-data files are preserved when the server is already populated.
