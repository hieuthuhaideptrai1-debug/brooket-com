# brooket.com — Public deployment package

This package is prepared to run the Brooket web app as a public Node.js web service.
The server already listens on `process.env.PORT` and binds to `0.0.0.0`, so it is
compatible with common Node hosting platforms.

## Important
This ZIP does NOT create a public Internet URL by itself. A hosting account/server
is required. A real `brooket.com` domain also has to be registered and its DNS
must point to the hosting service.

## Deploy with Render
1. Put this project in a Git repository (GitHub/GitLab).
2. Create a new Web Service on Render from that repository.
3. Render can use the included `render.yaml` settings.
4. Build command: `npm install`
5. Start command: `npm start`
6. After deployment, Render gives you a public `https://...onrender.com` address.
7. Add `brooket.com` as a custom domain in the hosting dashboard and configure the
   DNS records it provides.

## Persistence warning
The app writes accounts, chat, and bazaar data to JSON files. Many cloud hosts use
ephemeral disks, so data can be lost after a restart/redeploy unless persistent
storage is enabled. For a production public server, use a host with a persistent
disk/volume or migrate the JSON storage to a database.

## Local test
Run `npm install` and then `npm start`, then open:
http://localhost:3000/
