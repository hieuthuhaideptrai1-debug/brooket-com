BlooketStudio - Shared Account Persistence

This version stores player/admin accounts on the Node server instead of only in browser localStorage.

1. Run:
   npm install
   npm start

2. Open on the server computer:
   http://localhost:3000

3. On another computer on the same network, open:
   http://SERVER-IP:3000
   Example: http://192.168.1.10:3000

The shared account database is saved automatically in users-data.json next to server.js.
The browser localStorage is only a cache/fallback. Changes made by the Admin on one computer are pulled by other connected computers automatically.

Important: the Node server must remain running. Do not open index.html by itself when you want multiple computers to share accounts.


Persistence root-cause fix (v2.2):
- The browser no longer replaces the whole server database with a stale copy.
- Accounts are saved with an updatedAt timestamp and merged server-side.
- Multiple browsers/tabs can save without an older tab wiping newer account data.
- Server-side users-data.json remains the persistent database.
- Account deletion has a server endpoint when used by the app.
- Keep the Node server running and deploy it on a host with persistent storage.
