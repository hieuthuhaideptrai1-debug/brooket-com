ROOT LEADERBOARD FIX
- Shared accounts are merged instead of replacing local accounts.
- Account changes are persisted to /api/users with {users: ...}.
- updatedAt conflict protection prevents older browser data from overwriting newer data.
- Leaderboard reads the shared server and refreshes when remote player data changes.
- Existing account persistence behavior is preserved.

- Blooketstudio (Admin) is bootstrapped into the same server users database as all clone/player accounts, so Admin and clones use one root leaderboard.
- Opening index.html directly still uses the same localhost:3000 shared server; do not run separate Node servers for different copies.
