@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title BlooketStudio Web - One Click
set "RUNTIME=%~dp0.runtime"
set "NODEVER=22.18.0"
set "NODEDIR=%RUNTIME%\node-v%NODEVER%-win-x64"
set "NODEEXE=%NODEDIR%\node.exe"
set "NPMCMD=%NODEDIR%\npm.cmd"

if exist "%NODEEXE%" goto start
where node >nul 2>nul
if not errorlevel 1 (
  set "NODEEXE=node"
  goto start
)

if not exist "%RUNTIME%" mkdir "%RUNTIME%"
set "NODEZIP=%RUNTIME%\node.zip"
echo.
echo BlooketStudio is preparing its private Node.js runtime.
echo You do NOT need to install Node.js manually.
echo This may take a moment the first time.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing -Uri 'https://nodejs.org/dist/v%NODEVER%/node-v%NODEVER%-win-x64.zip' -OutFile '%NODEZIP%'; exit 0 } catch { exit 1 }"
if errorlevel 1 goto download_error
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%NODEZIP%' -DestinationPath '%RUNTIME%' -Force"
if errorlevel 1 goto extract_error
del /q "%NODEZIP%" >nul 2>nul
if not exist "%NODEEXE%" goto extract_error

:start
if not exist "node_modules\ws" (
  if "%NODEEXE%"=="node" (
    npm install --no-audit --no-fund >nul 2>&1
  ) else (
    "%NPMCMD%" install --no-audit --no-fund >nul 2>&1
  )
)

echo.
echo Starting BlooketStudio Web...
echo Opening http://localhost:3000/
echo Keep this window open while playing.
echo.
start "BlooketStudio Browser" http://localhost:3000/
if "%NODEEXE%"=="node" (
  node server.js
) else (
  "%NODEEXE%" server.js
)
if errorlevel 1 (
  echo.
  echo The server stopped. If this is the first run, please run START_WEB.bat again.
  pause
)
endlocal
exit /b

:download_error
echo.
echo Could not download the private runtime automatically.
echo Please check your internet connection, then double-click START_WEB.bat again.
pause
endlocal
exit /b 1

:extract_error
echo.
echo Could not prepare the private runtime.
echo Please delete the .runtime folder and double-click START_WEB.bat again.
pause
endlocal
exit /b 1
