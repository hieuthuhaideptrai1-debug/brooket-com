PACK MARKET COMPLETE
Files:
- index.html
- style.css
- script.js

Features:
Account login/register, Market, packs, Blooks, Stats, Leaderboard, Trade, Chat, PackBot Mythic/Chroma announcements, Settings, animated background.

Run:
Open index.html in a browser.

This is a front-end/localStorage demo. Accounts and chat are stored locally in the browser. Real online multiplayer/chat/trading requires a backend server and database.


NEW FEATURES:
- In Blooks, each Blook has "Làm avatar" and "Bán" buttons.
- Selected avatar is shown in the top bar, leaderboard, chat, and Trade player list.
- Trade is now player-to-player: choose another player, choose your Blook, choose their Blook, then send a request.
- Receiver gets Accept / Decline buttons. Accept swaps the two Blooks; declined/cancelled requests do not move items.
- Trade requests and accounts use localStorage in this demo, so they work between accounts in the same browser/device. Real cross-device multiplayer needs a backend/database.


NEW ADMIN FEATURES:
- Admin can select any player and any catalog Blook and set that Blook to 100% for the player's next/all pack openings until cleared.
- Admin can clear the forced Blook at any time.
- PackBot announcements are now posted directly inside the Chat as 🤖 PackBot messages; the separate Bot page was removed.

- Mythic Blooks now have a dedicated animated glow, floating motion and spark particles.
- Chroma Blooks have a stronger animated rainbow/hue effect.
- Pack result and inventory use the actual Blook SVG artwork from assets/blooks.
- Forced 100% Blooks keep the pack the player opened, so opening a BOT pack still displays BOT Pack.
- Same-browser tabs sync chat and account changes with BroadcastChannel when supported.
NOTE: This package is still a front-end demo. For truly global chat/account data across different devices, add a server/database (e.g. WebSocket + database).


PERSISTENCE ROOT FIX:
- A blank/new server users database no longer overwrites existing browser accounts.
- Existing local accounts are automatically migrated to the server when its database is empty.
- The server writes users-data.json atomically and keeps users-data.backup.json for recovery.
- Account data is preserved across browser/server restarts instead of being reset by an empty-server sync.
