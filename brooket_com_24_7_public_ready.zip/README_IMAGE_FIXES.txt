Image fixes in this build:
- Ankha avatar Blooks now use the correct pack-specific image instead of a duplicate emoji image from another pack.
- Avatar Blook images are constrained so oversized artwork cannot blow up the avatar.
- Rebuilt all 130 Blook SVG assets with a consistent emoji font fallback.
- Added missing Blook image assets for packs after Time Pack, preventing broken-image placeholders.
- Mythic/Chroma visual effects remain enabled.

- Blooks collection is now grouped by Pack in Pack order; each Pack shows its 5 Blooks, with locked/unowned entries separated from owned entries.
