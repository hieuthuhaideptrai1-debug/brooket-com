ADMIN PANEL — ALL ACCOUNT MODERATION

Default admin:
Username: blooketstudio
Password: Growgarden1@

Admin features:
- Edit Coins and ESP for any account.
- Ban / Unban ANY account, including admin accounts.
- Mute / Unmute ANY account, including admin accounts.
- Delete ANY account, including admin accounts and the currently signed-in account.
- View all local accounts and moderation status.
- Set/clear a forced 100% Blook for any account.

Important behavior:
- If the currently signed-in account is banned or deleted, the app logs that account out automatically.
- Deleting the default blooketstudio account is permanent for this browser; it will NOT be automatically recreated.
- This is a localStorage demo. These admin controls are client-side and are NOT secure for a real online game. For a real multiplayer service, enforce permissions and account changes on a server/database.
