Admin username: Blooketstudio
Admin password: Growgarden1@

Logging out removes only the current login session. The admin account remains available so you can log in again with the credentials above.
