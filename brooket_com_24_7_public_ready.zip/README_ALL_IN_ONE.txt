BlooketStudio - All-in-One build

Included features:
1. Admin panel can ban/unban, mute/unmute, change Coins/ESP, force Blook drops, and delete any player account, including the admin account.
2. Realtime multiplayer chat through WebSocket when served by server.js.
3. Chat messages are automatically removed after 24 hours.
4. Server checks expired messages every minute and on every connection.
5. Chat history is persisted in chat-data.json while messages are still within the 24-hour lifetime.

Run:
  npm install
  npm start
Then open:
  http://localhost:3000

Important:
- For players on different computers to see the same realtime chat, they must connect to the same running server URL.
- Opening index.html directly with file:// does not provide cross-device WebSocket chat.
