BlooketStudio 2.1 - Realtime Chat

LỖI CŨ:
Chat dùng localStorage nên mỗi máy/trình duyệt có một bản chat riêng. BroadcastChannel chỉ đồng bộ giữa các tab cùng origin trên cùng máy, không phải giữa các máy.

BẢN NÀY:
Chat dùng WebSocket server. Tin nhắn được server phát tới tất cả người chơi đang kết nối và lưu vào chat-data.json (tối đa 200 tin).

CÀI ĐẶT:
1. Cài Node.js.
2. Mở Terminal trong thư mục này.
3. Chạy: npm install
4. Chạy: npm start
5. Mở: http://localhost:3000

Để người chơi ở máy khác truy cập, chạy server trên máy/server có địa chỉ mạng mà họ truy cập được và mở cổng 3000 (hoặc dùng hosting hỗ trợ Node/WebSocket). Không dùng file index.html bằng cách double-click nếu muốn chat realtime.


CHAT AUTO-RESET (24 HOURS)
- Every chat message is stored with its creation time.
- A message is automatically deleted after 24 hours.
- The server checks for expired messages every minute and also cleans them when a player connects.
- Restarting the server does not restore expired messages.


Presence update: server now tracks online players over WebSocket, so players on different browsers/devices connected to the same server can see who is online in Chat.
