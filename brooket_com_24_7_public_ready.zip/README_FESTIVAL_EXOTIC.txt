Festival Exotic update

- Rarity/tier order in the Festival Exotic UI: Untrusted (highest) > Mythical > Chroma.
- Drop odds remain 98.00% / 1.75% / 0.25% respectively.
- All three Festival Exotic Blooks have a prominent animated rainbow aura/effect.
- The existing Brooket interface, Blooks, Bazaar, accounts, packs, chat, and other features are preserved.
- Festival Exotic pack cost remains 2,500 Tokens.

UI update: Festival Exotic now uses the same Admin-only crown/badge styling as Verity Pack. Festival Exotic remains Admin-only and costs 1 Token.
